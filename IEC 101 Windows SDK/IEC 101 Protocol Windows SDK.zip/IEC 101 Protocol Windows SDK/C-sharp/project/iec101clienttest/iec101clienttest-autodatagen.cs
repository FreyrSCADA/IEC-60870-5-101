/******************************************************************************
*
* (c) 2018 by FreyrSCADA Embedded Solution Pvt Ltd
*
********************************************************************************
*
* Disclaimer: This program is an example and should be used as such.
*             If you wish to use this program or parts of it in your application,
*             you must validate the code yourself.  FreyrSCADA Embedded Solution Pvt Ltd
*             can not be held responsible for the correct functioning
*             or coding of this example
*******************************************************************************/

/*****************************************************************************/
/*! \file       iec101clienttest-autodatagen.cs
 *  \brief      C# Source code file, IEC 60870-5-101 Client library test program - auto gen data
 *
 *  \par        FreyrSCADA Embedded Solution Pvt Ltd
 *              Email   : support@freyrscada.com
 */
/*****************************************************************************/


/*! \brief - In a loop simulate issue command - for particular IOA , value changes - issue a command to server  */
#define SIMULATE_COMMAND 

/*! \brief - Enable traffic flags to show transmit and receive signal  */
#define VIEW_TRAFFIC 

using System;
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace iec101test
{
    
    class Program
    {
        
        [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Explicit)]
        struct SingleInt32Union
        {
            [System.Runtime.InteropServices.FieldOffset(0)]
            public float f;
            [System.Runtime.InteropServices.FieldOffset(0)]
            public int i;
        }


        /******************************************************************************
        * Update callback
        ******************************************************************************/
        static short cbUpdate(ushort u16ObjectId, ref iec101.sIEC101DataAttributeID ptUpdateID, ref iec101.sIEC101DataAttributeData ptUpdateValue, ref iec101.sIEC101UpdateParameters ptUpdateParams, ref short ptErrorValue)
        {
            Console.WriteLine("\n\r\ncbUpdate() called");
            Console.WriteLine("Client ID " + u16ObjectId);
            Console.WriteLine(" Data Link Address "+ ptUpdateID.u16DataLinkAddress);
            Console.WriteLine(" Station Address "+ ptUpdateID.u16CommonAddress);

            Console.WriteLine("Data Attribute ID is  {0:D} IOA {1:D} ", ptUpdateID.eTypeID, ptUpdateID.u32IOA);
            Console.WriteLine("Data is  datatype->{0:D} datasize->{1:D}  ", ptUpdateValue.eDataType, ptUpdateValue.eDataSize);

            if ((ptUpdateID.eTypeID == iec101.eIEC870TypeID.M_EP_TB_1) || (ptUpdateID.eTypeID == iec101.eIEC870TypeID.M_EP_TE_1))
            {
                byte u8data = unchecked((byte)System.Runtime.InteropServices.Marshal.ReadByte(ptUpdateValue.pvData));

                if ((u8data & (byte)iec101.eStartEventsofProtFlags.GS) == (byte)iec101.eStartEventsofProtFlags.GS)
                {
                    Console.WriteLine("General start of operation");
                }

                if ((u8data & (byte)iec101.eStartEventsofProtFlags.SL1) == (byte)iec101.eStartEventsofProtFlags.SL1)
                {
                    Console.WriteLine("Start of operation phase L1");
                }

                if ((u8data & (byte)iec101.eStartEventsofProtFlags.SL2) == (byte)iec101.eStartEventsofProtFlags.SL2)
                {
                    Console.WriteLine("Start of operation phase L2");
                }

                if ((u8data & (byte)iec101.eStartEventsofProtFlags.SL3) == (byte)iec101.eStartEventsofProtFlags.SL3)
                {
                    Console.WriteLine("Start of operation phase L3");
                }

                if ((u8data & (byte)iec101.eStartEventsofProtFlags.SIE) == (byte)iec101.eStartEventsofProtFlags.SIE)
                {
                    Console.WriteLine("Start of operation IE");
                }

                if ((u8data & (byte)iec101.eStartEventsofProtFlags.SRD) == (byte)iec101.eStartEventsofProtFlags.SRD)
                {
                    Console.WriteLine("Start of operation in reverse direction");
                }
            }
            else if ((ptUpdateID.eTypeID == iec101.eIEC870TypeID.M_EP_TC_1) || (ptUpdateID.eTypeID == iec101.eIEC870TypeID.M_EP_TF_1))
                {

                    byte u8data = unchecked((byte)System.Runtime.InteropServices.Marshal.ReadByte(ptUpdateValue.pvData));


                    if ((u8data & (byte)iec101.ePackedOutputCircuitInfoofProtFlags.GC) == (byte)iec101.ePackedOutputCircuitInfoofProtFlags.GC)
                    {
                        Console.WriteLine("General command to output circuit ");
                    }

                    if ((u8data & (byte)iec101.ePackedOutputCircuitInfoofProtFlags.CL1) == (byte)iec101.ePackedOutputCircuitInfoofProtFlags.CL1)
                    {
                        Console.WriteLine("Command to output circuit phase L1");
                    }

                    if ((u8data & (byte)iec101.ePackedOutputCircuitInfoofProtFlags.CL2) == (byte)iec101.ePackedOutputCircuitInfoofProtFlags.CL2)
                    {
                        Console.WriteLine("Command to output circuit phase L2");
                    }

                    if ((u8data & (byte)iec101.ePackedOutputCircuitInfoofProtFlags.CL3) == (byte)iec101.ePackedOutputCircuitInfoofProtFlags.CL3)
                    {
                        Console.WriteLine("Command to output circuit phase L3");
                    }

                }
                else
                {

                    switch (ptUpdateValue.eDataType)
                    {
                        case iec101.eDataTypes.SINGLE_POINT_DATA:
                        case iec101.eDataTypes.DOUBLE_POINT_DATA:
                        case iec101.eDataTypes.UNSIGNED_BYTE_DATA:
                            Console.WriteLine("Data : {0:D}", System.Runtime.InteropServices.Marshal.ReadByte(ptUpdateValue.pvData));
                            break;

                        case iec101.eDataTypes.SIGNED_BYTE_DATA:
                            sbyte i8data = unchecked((sbyte)System.Runtime.InteropServices.Marshal.ReadByte(ptUpdateValue.pvData));
                            Console.WriteLine(i8data);
                            break;

                        case iec101.eDataTypes.UNSIGNED_WORD_DATA:
                            ushort u16data = unchecked((ushort)System.Runtime.InteropServices.Marshal.ReadInt16(ptUpdateValue.pvData));
                            Console.WriteLine(u16data);
                            break;

                        case iec101.eDataTypes.SIGNED_WORD_DATA:
                            Console.WriteLine("Data : {0:D}", System.Runtime.InteropServices.Marshal.ReadInt16(ptUpdateValue.pvData));
                            break;

                        case iec101.eDataTypes.UNSIGNED_DWORD_DATA:
                            uint u32data = unchecked((uint)System.Runtime.InteropServices.Marshal.ReadInt32(ptUpdateValue.pvData));
                            Console.WriteLine(u32data);
                            break;

                        case iec101.eDataTypes.SIGNED_DWORD_DATA:
                            Console.WriteLine("Data : {0:D}", System.Runtime.InteropServices.Marshal.ReadInt32(ptUpdateValue.pvData));
                            break;

                        case iec101.eDataTypes.FLOAT32_DATA:
                            SingleInt32Union f32data;
                            f32data.f = 0;
                            f32data.i = System.Runtime.InteropServices.Marshal.ReadInt32(ptUpdateValue.pvData);
                            Console.WriteLine("Data : {0:F}", f32data.f);
                            break;

                        default:
                            break;
                    }

                }


            if (ptUpdateValue.tQuality != (ushort)iec101.eIEC870QualityFlags.GD)
                {

                    /* Now for the Status */
                    if ((ptUpdateValue.tQuality & (ushort)iec101.eIEC870QualityFlags.IV) == (ushort)iec101.eIEC870QualityFlags.IV)
                    {
                        Console.WriteLine("IEC_INVALID_FLAG");
                    }

                    if ((ptUpdateValue.tQuality & (ushort)iec101.eIEC870QualityFlags.NT) == (ushort)iec101.eIEC870QualityFlags.NT)
                    {
                        Console.WriteLine("IEC_NONTOPICAL_FLAG");
                    }

                    if ((ptUpdateValue.tQuality & (ushort)iec101.eIEC870QualityFlags.SB) == (ushort)iec101.eIEC870QualityFlags.SB)
                    {
                        Console.WriteLine("IEC_SUBSTITUTED_FLAG");
                    }

                    if ((ptUpdateValue.tQuality & (ushort)iec101.eIEC870QualityFlags.BL) == (ushort)iec101.eIEC870QualityFlags.BL)
                    {
                        Console.WriteLine("IEC_BLOCKED_FLAG");
                    }

                    if ((ptUpdateValue.tQuality & (ushort)iec101.eIEC870QualityFlags.OV) == (ushort)iec101.eIEC870QualityFlags.OV)
                    {
                        Console.WriteLine("IEC_OV_FLAG");
                    }

                    if ((ptUpdateValue.tQuality & (ushort)iec101.eIEC870QualityFlags.EI) == (ushort)iec101.eIEC870QualityFlags.EI)
                    {
                        Console.WriteLine("IEC_EI_FLAG");
                    }

                    if ((ptUpdateValue.tQuality & (ushort)iec101.eIEC870QualityFlags.TR) == (ushort)iec101.eIEC870QualityFlags.TR)
                    {
                        Console.WriteLine("IEC_TR_FLAG");
                    }

                    if ((ptUpdateValue.tQuality & (ushort)iec101.eIEC870QualityFlags.CA) == (ushort)iec101.eIEC870QualityFlags.CA)
                    {
                        Console.WriteLine("IEC_CA_FLAG");
                    }

                    if ((ptUpdateValue.tQuality & (ushort)iec101.eIEC870QualityFlags.CR) == (ushort)iec101.eIEC870QualityFlags.CR)
                    {
                        Console.WriteLine("IEC_CR_FLAG");
                    }


                }

            if ((ptUpdateID.eTypeID == iec101.eIEC870TypeID.M_EP_TA_1) ||
                    (ptUpdateID.eTypeID == iec101.eIEC870TypeID.M_EP_TB_1) ||
                    (ptUpdateID.eTypeID == iec101.eIEC870TypeID.M_EP_TC_1) ||
                    (ptUpdateID.eTypeID == iec101.eIEC870TypeID.M_EP_TD_1) ||
                    (ptUpdateID.eTypeID == iec101.eIEC870TypeID.M_EP_TE_1) ||
                    (ptUpdateID.eTypeID == iec101.eIEC870TypeID.M_EP_TF_1))
                {
                    Console.WriteLine(" Elapsed time {0:D}", ptUpdateValue.u16ElapsedTime);
                }



            Console.WriteLine(" COT:" + ptUpdateParams.eCause);


            if (ptUpdateValue.sTimeStamp.u8Seconds != 0)
            {

                Console.WriteLine("Date : {0:D}-{1:D}-{2:D}  DOW -{3:D}", ptUpdateValue.sTimeStamp.u8Day, ptUpdateValue.sTimeStamp.u8Month, ptUpdateValue.sTimeStamp.u16Year, ptUpdateValue.sTimeStamp.u8DayoftheWeek);

                Console.WriteLine("Time : {0:D}:{1:D2}:{2:D2}:{3:D4}:{4:D4}", ptUpdateValue.sTimeStamp.u8Hour, ptUpdateValue.sTimeStamp.u8Minute, ptUpdateValue.sTimeStamp.u8Seconds, ptUpdateValue.sTimeStamp.u16MilliSeconds, ptUpdateValue.sTimeStamp.u16MicroSeconds);
            }


            return (short)iec101.eTgtErrorCodes.EC_NONE;
        }

        /******************************************************************************
        * client status callback
        ******************************************************************************/
        static short cbClientStatus(ushort u16ObjectId, ref  iec101.sIEC101DataAttributeID psDAID, ref iec101.eStatus peSat, ref short ptErrorValue)
        {
            Console.WriteLine("\r\r\ncbClientstatus() called");
            Console.WriteLine("Client ID " + u16ObjectId);

            if (peSat == iec101.eStatus.CONNECTED)
            {
                Console.WriteLine(" Status - Connected");
            }
            else
            {
                Console.WriteLine(" Status - Disconnected");
            }

            Console.WriteLine(" Data Link address " + psDAID.u16DataLinkAddress);
            Console.WriteLine(" Server Common Address " + psDAID.u16CommonAddress);
            Console.WriteLine(" Serial port number " + psDAID.u8SerialPortNumber);



            return (short)iec101.eTgtErrorCodes.EC_NONE;
        }


        /******************************************************************************
        * Debug callback
        ******************************************************************************/
        static short cbDebug(ushort u16ObjectId, ref iec101.sIEC101DebugData ptDebugData, ref short ptErrorValue)
        {
            //Console.Write("\r\ncbDebug() called");
            Console.Write("\r\nClient ID " + u16ObjectId);

            Console.Write("{0:D}-{1:D}-{2:D} ", ptDebugData.sTimeStamp.u8Day, ptDebugData.sTimeStamp.u8Month, ptDebugData.sTimeStamp.u16Year);

            Console.Write(" {0:D}:{1:D2}:{2:D2}:{3:D4}:{4:D4}", ptDebugData.sTimeStamp.u8Hour, ptDebugData.sTimeStamp.u8Minute, ptDebugData.sTimeStamp.u8Seconds, ptDebugData.sTimeStamp.u16MilliSeconds, ptDebugData.sTimeStamp.u16MicroSeconds);

            if ((ptDebugData.u32DebugOptions & (uint)iec101.eDebugOptionsFlag.DEBUG_OPTION_RX) == (uint)iec101.eDebugOptionsFlag.DEBUG_OPTION_RX)
            {

                Console.Write("Rx " + " Serial port " + ptDebugData.u8ComportNumber + " <- ");

                for (ushort i = 0; i < ptDebugData.u16RxCount; i++)
                    Console.Write("{0:X2} ", ptDebugData.au8RxData[i]);
                
            }

            if ((ptDebugData.u32DebugOptions & (uint)iec101.eDebugOptionsFlag.DEBUG_OPTION_TX) == (uint)iec101.eDebugOptionsFlag.DEBUG_OPTION_TX)
            {
                Console.Write("Tx " + " Serial port " + ptDebugData.u8ComportNumber + " -> ");

                for (ushort i = 0; i < ptDebugData.u16TxCount; i++)
                    Console.Write("{0:X2} ", ptDebugData.au8TxData[i]);
               
            }

            if ((ptDebugData.u32DebugOptions & (uint)iec101.eDebugOptionsFlag.DEBUG_OPTION_ERROR) == (uint)iec101.eDebugOptionsFlag.DEBUG_OPTION_ERROR)
            {
                Console.WriteLine("Error message " + ptDebugData.au8ErrorMessage);
                Console.WriteLine("ErrorCode " + ptDebugData.i16ErrorCode);
                Console.WriteLine("ErrorValue " + ptDebugData.tErrorvalue);
            }

            if ((ptDebugData.u32DebugOptions & (uint)iec101.eDebugOptionsFlag.DEBUG_OPTION_WARNING) == (uint)iec101.eDebugOptionsFlag.DEBUG_OPTION_WARNING)
            {

                Console.WriteLine("Warning message " + ptDebugData.au8WarningMessage);
                Console.WriteLine("ErrorCode " + ptDebugData.i16ErrorCode);
                Console.WriteLine("ErrorValue " + ptDebugData.tErrorvalue);
            }

            return (short)iec101.eTgtErrorCodes.EC_NONE;
        }

        /******************************************************************************
        * Error code - Print information
        ******************************************************************************/
        static string errorcodestring(short errorcode)
        {
            iec101.sIEC101ErrorCode sIEC101ErrorCodeDes;
            sIEC101ErrorCodeDes = new iec101.sIEC101ErrorCode();

            sIEC101ErrorCodeDes.iErrorCode = errorcode;
            sIEC101ErrorCodeDes.LongDes = "";
            sIEC101ErrorCodeDes.shortDes = "";

            iec101.IEC101ErrorCodeString( ref sIEC101ErrorCodeDes);

            string returnmessage = sIEC101ErrorCodeDes.LongDes;

            return returnmessage;
        }

        /******************************************************************************
        * Error value - Print information
        ******************************************************************************/
        static string  errorvaluestring(short errorvalue)
        {
            iec101.sIEC101ErrorValue sIEC101ErrorValueDes;
            sIEC101ErrorValueDes = new iec101.sIEC101ErrorValue(); 

             sIEC101ErrorValueDes.iErrorValue = errorvalue;

             iec101.IEC101ErrorValueString(ref sIEC101ErrorValueDes);

             string returnmessage = sIEC101ErrorValueDes.LongDes;

             return returnmessage;
        }


        /******************************************************************************
        * main()
        ******************************************************************************/
        static void Main(string[] args)
        {


            System.DateTime date;                   // update date and time structute
            System.IntPtr iec101clienthandle;       // IEC 60870-5-101 Client object
            iec101.sIEC101Parameters sParameters;    // IEC101 Client object callback paramters 
            iec101.sIEC101DataAttributeID sWriteDAID;       // Command data identification parameters
            iec101.sIEC101DataAttributeData sWriteValue;    // Command data value parameters
            iec101.sIEC101CommandParameters sCommandParams; // Command data parameters

            System.Console.WriteLine(" \t\t**** FreyrSCADA - IEC 60870-5-101 Client Library Test ****");

            try
            {
                if (String.Compare(iec101.IEC101GetLibraryVersion(), iec101.IEC101_VERSION, true) != 0)
                {
                    System.Console.WriteLine("\r\nError: Version Number Mismatch");
                    System.Console.WriteLine("Library Version is : {0:D}", iec101.IEC101GetLibraryVersion());
                    System.Console.WriteLine("The Version used is : {0:D}", iec101.IEC101_VERSION);
                    System.Console.Write("Press <Enter> to exit... ");
                    while (Console.ReadKey().Key != ConsoleKey.Enter) { }
                    return;
                }
            }
            catch (DllNotFoundException e)
            {
                System.Console.WriteLine(e.ToString());
                System.Console.Write("Press <Enter> to exit... ");
                while (Console.ReadKey().Key != ConsoleKey.Enter) { }
                return;
            }

            System.Console.WriteLine("Library Version is : {0:D}", iec101.IEC101GetLibraryVersion());
            System.Console.WriteLine("Library Build on   : {0:D}", iec101.IEC101GetLibraryBuildTime());
            System.Console.WriteLine("Library Licence Information  : {0:D}", iec101.IEC101GetLibraryLicenseInfo());


            iec101clienthandle = System.IntPtr.Zero;
            sParameters = new iec101.sIEC101Parameters();

            // Initialize IEC 60870-5-101 Server object parameters
            sParameters.eAppFlag = iec101.eApplicationFlag.APP_CLIENT;                      // This is a IEC101 Server
            sParameters.ptReadCallback = null;                                              // Read Callback
            sParameters.ptWriteCallback = null;                                             // Write Callback
            sParameters.ptUpdateCallback = cbUpdate;                                        // Update Callback
            sParameters.ptSelectCallback = null;                                            // Select commands
            sParameters.ptOperateCallback = null;                                           // Operate commands
            sParameters.ptCancelCallback = null;                                            // Cancel commands
            sParameters.ptFreezeCallback = null;                                            // Freeze Callback
            sParameters.ptPulseEndActTermCallback = null;                                   // pulse end callback
            sParameters.ptParameterActCallback = null;                                      // Parameter activation callback
            sParameters.ptDebugCallback = new iec101.IEC101DebugMessageCallback(cbDebug);   // Debug Callback
            sParameters.ptClientStatusCallback = cbClientStatus;                            // client connection status callback
            sParameters.ptDirectoryCallback = null;                                         // client Directory callback
            sParameters.u16ObjectId = 1;
            sParameters.u32Options = 0;
            short eErrorCode = 0;                                                              // API Function return error paramter
            short ptErrorValue = 0;                                                          // API Function return addtional error paramter


            do
            {
                // Create a Client object
                iec101clienthandle = iec101.IEC101Create(ref sParameters, ref eErrorCode, ref ptErrorValue);
                if (iec101clienthandle == System.IntPtr.Zero)
                {
                    System.Console.WriteLine("IEC 60870-5-101 Library API Function - IEC101Create failed");
					System.Console.WriteLine("ErrorCode {0:D}: {1}", eErrorCode, errorcodestring(eErrorCode));
                    System.Console.WriteLine("ErrorValue {0:D}: {1}", ptErrorValue, errorvaluestring(ptErrorValue));
                    break;
                }

                iec101.sIEC101ConfigurationParameters sIEC101Config;
                sIEC101Config = new iec101.sIEC101ConfigurationParameters();
                // Client load configuration - communication and protocol configuration parameters         


                sIEC101Config.sClientSet.benabaleUTCtime = 0;
#if VIEW_TRAFFIC
				sIEC101Config.sClientSet.sDebug.u32DebugOptions = (uint)(iec101.eDebugOptionsFlag.DEBUG_OPTION_TX | iec101.eDebugOptionsFlag.DEBUG_OPTION_RX);
                
#else
				sIEC101Config.sClientSet.sDebug.u32DebugOptions = 0;
#endif			
                //client 1 configuration Starts                
                sIEC101Config.sClientSet.u8NoofClient = 1;
                iec101.sClientObject[] psClientObjects = new iec101.sClientObject[sIEC101Config.sClientSet.u8NoofClient];
                sIEC101Config.sClientSet.psClientObjects = System.Runtime.InteropServices.Marshal.AllocHGlobal(
                sIEC101Config.sClientSet.u8NoofClient * System.Runtime.InteropServices.Marshal.SizeOf(psClientObjects[0]));

                sIEC101Config.sClientSet.eLink = iec101.eDataLinkTransmission.UNBALANCED_MODE;          // Data Link Mode 
                psClientObjects[0].sSerialSet.eSerialType = iec101.eSerialTypes.SERIAL_RS232;
                psClientObjects[0].sSerialSet.u8SerialPortNumber = 2;
                psClientObjects[0].sSerialSet.eSerialBitRate = iec101.eSerialBitRate.BITRATE_9600;
                psClientObjects[0].sSerialSet.eWordLength = iec101.eSerialWordLength.WORDLEN_8BITS;
                psClientObjects[0].sSerialSet.eSerialParity = iec101.eSerialParity.EVEN;
                psClientObjects[0].sSerialSet.eStopBits = iec101.eSerialStopBits.STOPBIT_1BIT;

                //windows serial port flow control
                psClientObjects[0].sSerialSet.sFlowControl.bWinCTSoutputflow = 0;
                psClientObjects[0].sSerialSet.sFlowControl.bWinDSRoutputflow = 0;
                psClientObjects[0].sSerialSet.sFlowControl.eWinDTR = iec101.eWinDTRcontrol.WIN_DTR_CONTROL_DISABLE;
                psClientObjects[0].sSerialSet.sFlowControl.eWinRTS = iec101.eWinRTScontrol.WIN_RTS_CONTROL_DISABLE;

                psClientObjects[0].sSerialSet.sFlowControl.eLinuxFlowControl = iec101.eLinuxSerialFlowControl.FLOW_NONE;

                psClientObjects[0].sSerialSet.sRxTimeParam.u16CharacterTimeout = 1;
                psClientObjects[0].sSerialSet.sRxTimeParam.u16MessageTimeout = 0;
                psClientObjects[0].sSerialSet.sRxTimeParam.u16InterCharacterDelay = 5;
                psClientObjects[0].sSerialSet.sRxTimeParam.u16PostDelay = 0;
                psClientObjects[0].sSerialSet.sRxTimeParam.u16PreDelay = 0;
                psClientObjects[0].sSerialSet.sRxTimeParam.u8CharacterRetries = 20;
                psClientObjects[0].sSerialSet.sRxTimeParam.u8MessageRetries = 0;



                psClientObjects[0].sClientProtSet.eCASize = iec101.eCommonAddressSize.CA_TWO_BYTE;
                psClientObjects[0].sClientProtSet.eCOTsize = iec101.eCauseofTransmissionSize.COT_TWO_BYTE;
                psClientObjects[0].sClientProtSet.u8OriginatorAddress = 1;
                psClientObjects[0].sClientProtSet.eIOAsize = iec101.eInformationObjectAddressSize.IOA_TWO_BYTE;
                psClientObjects[0].sClientProtSet.elinkAddrSize = iec101.eDataLinkAddressSize.DL_TWO_BYTE;
                psClientObjects[0].sClientProtSet.u8TotalNumberofStations = 1;
                psClientObjects[0].sClientProtSet.au16CommonAddress = new ushort[5] { 1, 0, 0, 0, 0 };
                psClientObjects[0].sClientProtSet.u16DataLinkAddress = 1;
                psClientObjects[0].sClientProtSet.u32LinkLayerTimeout = 5000;
                psClientObjects[0].sClientProtSet.u32PollInterval = 100;

                psClientObjects[0].sClientProtSet.u32GeneralInterrogationInterval = 5;    /*!< in sec if 0 , gi will not send in particular interval*/
                psClientObjects[0].sClientProtSet.u32Group1InterrogationInterval = 0;    /*!< in sec if 0 , group 1 interrogation will not send in particular interval*/
                psClientObjects[0].sClientProtSet.u32Group2InterrogationInterval = 0;    /*!< in sec if 0 , group 1 interrogation will not send in particular interval*/
                psClientObjects[0].sClientProtSet.u32Group3InterrogationInterval = 0;    /*!< in sec if 0 , group 1 interrogation will not send in particular interval*/
                psClientObjects[0].sClientProtSet.u32Group4InterrogationInterval = 0;    /*!< in sec if 0 , group 1 interrogation will not send in particular interval*/
                psClientObjects[0].sClientProtSet.u32Group5InterrogationInterval = 0;    /*!< in sec if 0 , group 1 interrogation will not send in particular interval*/
                psClientObjects[0].sClientProtSet.u32Group6InterrogationInterval = 0;    /*!< in sec if 0 , group 1 interrogation will not send in particular interval*/
                psClientObjects[0].sClientProtSet.u32Group7InterrogationInterval = 0;    /*!< in sec if 0 , group 1 interrogation will not send in particular interval*/
                psClientObjects[0].sClientProtSet.u32Group8InterrogationInterval = 0;    /*!< in sec if 0 , group 1 interrogation will not send in particular interval*/
                psClientObjects[0].sClientProtSet.u32Group9InterrogationInterval = 0;    /*!< in sec if 0 , group 1 interrogation will not send in particular interval*/
                psClientObjects[0].sClientProtSet.u32Group10InterrogationInterval = 0;    /*!< in sec if 0 , group 1 interrogation will not send in particular interval*/
                psClientObjects[0].sClientProtSet.u32Group11InterrogationInterval = 0;    /*!< in sec if 0 , group 1 interrogation will not send in particular interval*/
                psClientObjects[0].sClientProtSet.u32Group12InterrogationInterval = 0;    /*!< in sec if 0 , group 1 interrogation will not send in particular interval*/
                psClientObjects[0].sClientProtSet.u32Group13InterrogationInterval = 0;    /*!< in sec if 0 , group 1 interrogation will not send in particular interval*/
                psClientObjects[0].sClientProtSet.u32Group14InterrogationInterval = 0;    /*!< in sec if 0 , group 1 interrogation will not send in particular interval*/
                psClientObjects[0].sClientProtSet.u32Group15InterrogationInterval = 0;    /*!< in sec if 0 , group 1 interrogation will not send in particular interval*/
                psClientObjects[0].sClientProtSet.u32Group16InterrogationInterval = 0;    /*!< in sec if 0 , group 1 interrogation will not send in particular interval*/
                psClientObjects[0].sClientProtSet.u32CounterInterrogationInterval = 5;    /*!< in sec if 0 , ci will not send in particular interval*/
                psClientObjects[0].sClientProtSet.u32Group1CounterInterrogationInterval = 0;    /*!< in sec if 0 , group 1 counter interrogation will not send in particular interval*/
                psClientObjects[0].sClientProtSet.u32Group2CounterInterrogationInterval = 0;    /*!< in sec if 0 , group 1 counter interrogation will not send in particular interval*/
                psClientObjects[0].sClientProtSet.u32Group3CounterInterrogationInterval = 0;    /*!< in sec if 0 , group 1 counter interrogation will not send in particular interval*/
                psClientObjects[0].sClientProtSet.u32Group4CounterInterrogationInterval = 0;    /*!< in sec if 0 , group 1 counter interrogation will not send in particular interval*/
                psClientObjects[0].sClientProtSet.u32ClockSyncInterval = 5;              /*!< in sec if 0 , clock sync, will not send in particular interval */


                psClientObjects[0].sClientProtSet.u32CommandTimeout = 10000;
                psClientObjects[0].sClientProtSet.bCommandResponseActtermUsed = 1;

                // File transfer protocol configuration parameters
                psClientObjects[0].sClientProtSet.bEnableFileTransfer = 0;
                psClientObjects[0].sClientProtSet.u32FileTransferTimeout = 1000000;
                psClientObjects[0].sClientProtSet.ai8FileTransferDirPath= "//FileTest//";


                sIEC101Config.sClientSet.bAutoGenIEC101DataObjects = 1;

                psClientObjects[0].u16NoofObject = 0;        // Define number of objects
                
                // Allocate memory for objects
                psClientObjects[0].psIEC101Objects = System.IntPtr.Zero;


                IntPtr tmp1 = new IntPtr(sIEC101Config.sClientSet.psClientObjects.ToInt32());
                System.Runtime.InteropServices.Marshal.StructureToPtr(psClientObjects[0], tmp1, true);



                // Load configuration
                eErrorCode = iec101.IEC101LoadConfiguration(iec101clienthandle, ref sIEC101Config, ref ptErrorValue);
                if (eErrorCode != 0)
                {
                    System.Console.WriteLine("IEC 60870-5-101 Library API Function - IEC101LoadConfiguration failed");
					System.Console.WriteLine("ErrorCode {0:D}: {1}", eErrorCode, errorcodestring(eErrorCode));
                    System.Console.WriteLine("ErrorValue {0:D}: {1}", ptErrorValue, errorvaluestring(ptErrorValue));
                    break;
                }

                // Start server
                eErrorCode = iec101.IEC101Start(iec101clienthandle, ref ptErrorValue);
                if (eErrorCode != 0)
                {
                    System.Console.WriteLine("IEC 60870-5-101 Library API Function - IEC101Start failed");
					System.Console.WriteLine("ErrorCode {0:D}: {1}", eErrorCode, errorcodestring(eErrorCode));
                    System.Console.WriteLine("ErrorValue {0:D}: {1}", ptErrorValue, errorvaluestring(ptErrorValue));
                    break;
                }  
                
 #if SIMULATE_COMMAND               
                // command data
                sWriteDAID = new iec101.sIEC101DataAttributeID();               // Command data identification parameters
                sWriteValue = new iec101.sIEC101DataAttributeData();            // Command data value parameters
                sCommandParams = new iec101.sIEC101CommandParameters();         // Command data parameters


                sWriteDAID.u8SerialPortNumber = 2;
                sWriteDAID.u16DataLinkAddress = 1;                
                sWriteDAID.eTypeID = iec101.eIEC870TypeID.C_SE_TC_1;
                sWriteDAID.u32IOA = 100;
                sWriteDAID.u16CommonAddress = 1;

                sWriteValue.tQuality = (ushort)iec101.eIEC870QualityFlags.GD;


                sWriteValue.pvData = System.Runtime.InteropServices.Marshal.AllocHGlobal((int)iec101.eDataSizes.FLOAT32_SIZE);
                sWriteValue.eDataType = iec101.eDataTypes.FLOAT32_DATA;
                sWriteValue.eDataSize = iec101.eDataSizes.FLOAT32_SIZE;

                SingleInt32Union f32data;
                f32data.i = 0;
                f32data.f = 1;
#endif

                System.Console.WriteLine("Enter CTRL-X to Exit");
               
                Thread.Sleep(3000);

                while (true)
                {
                    if (Console.KeyAvailable) // since .NET 2.0
                    {
                        char c = Console.ReadKey().KeyChar;
                        if (c == 24)
                        {
                            break;
                        }
                    }
                    else
                    {

#if SIMULATE_COMMAND  
                        date = DateTime.Now;
                        //current date 
                        sWriteValue.sTimeStamp.u8Day = (byte)date.Day;
                        sWriteValue.sTimeStamp.u8Month = (byte)date.Month;
                        sWriteValue.sTimeStamp.u16Year = (ushort)date.Year;

                        //time
                        sWriteValue.sTimeStamp.u8Hour = (byte)date.Hour;
                        sWriteValue.sTimeStamp.u8Minute = (byte)date.Minute;
                        sWriteValue.sTimeStamp.u8Seconds = (byte)date.Second;
                        sWriteValue.sTimeStamp.u16MilliSeconds = (ushort)date.Millisecond;
                        sWriteValue.sTimeStamp.u16MicroSeconds = 0;
                        sWriteValue.sTimeStamp.i8DSTTime = 0; //No Day light saving time
                        sWriteValue.sTimeStamp.u8DayoftheWeek = (byte)date.DayOfWeek;



                        f32data.f += 0.1f;


                        Console.WriteLine("Command Measured Value {0:F}", f32data.f);

                        System.Runtime.InteropServices.Marshal.WriteInt32(sWriteValue.pvData, f32data.i);

                        // operate command
                        eErrorCode = iec101.IEC101Operate(iec101clienthandle, ref sWriteDAID, ref sWriteValue, ref sCommandParams, ref ptErrorValue);
                        if (eErrorCode != 0)
                        {
                            Console.WriteLine("IEC 60870-5-101 Library API Function - IEC101Operate() failed: {0:D} {1:D}", eErrorCode, ptErrorValue);
                        	System.Console.WriteLine("ErrorCode {0:D}: {1}", eErrorCode, errorcodestring(eErrorCode));
							System.Console.WriteLine("ErrorValue {0:D}: {1}", ptErrorValue, errorvaluestring(ptErrorValue));
						}

#endif
//Sending Command data - time interval
                        Thread.Sleep(5000);
                    }
                }

                // Stop Client
                eErrorCode = iec101.IEC101Stop(iec101clienthandle, ref ptErrorValue);
                if (eErrorCode != 0)
                {
                    System.Console.WriteLine("IEC 60870-5-101 Library API Function - IEC101Stop failed");
					System.Console.WriteLine("ErrorCode {0:D}: {1}", eErrorCode, errorcodestring(eErrorCode));
                    System.Console.WriteLine("ErrorValue {0:D}: {1}", ptErrorValue, errorvaluestring(ptErrorValue));
                    break;
                }

                // Free Client
                eErrorCode = iec101.IEC101Free(iec101clienthandle, ref ptErrorValue);
                if (eErrorCode != 0)
                {
                    System.Console.WriteLine("IEC 60870-5-101 Library API Function - IEC101Free failed");
					System.Console.WriteLine("ErrorCode {0:D}: {1}", eErrorCode, errorcodestring(eErrorCode));
                    System.Console.WriteLine("ErrorValue {0:D}: {1}", ptErrorValue, errorvaluestring(ptErrorValue));
                    break;
                }

                

            } while (false);



            System.Console.Write("Press <Enter> to Exit... ");
            while (Console.ReadKey().Key != ConsoleKey.Enter) { }

        }        
    }            
}
